//
//  DOTSamFace.h
//  SamCPPTest
//
//  Created by Jakub Vallo on 31/03/2022.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef struct sam_face_color_image
{
    unsigned int width;
    unsigned int height;
    unsigned int *imageArray;
} SamFaceColorImage;

@interface DOTSamFace : NSObject

+ (int)samFaceInit;
+ (int)samFaceTerminate;
+ (int)samFaceGetMajorVersion:(int *)majorVersion minorVersion:(int *)minorVersion patchVersion:(int *)patchVersion;
+ (char const *)samFaceGetInfoString;
+ (int)samFaceSetLoggerWithFilename:(char *)filename severity:(int)severity;
+ (int)samFaceDetectFacesWithRawImage:(SamFaceColorImage *)rawImage options:(int)options maxCandidates:(int)maxCandidates boundingBoxes:(int *)boundingBoxes confidence:(int *)confidence faceParams:(int *)faceParams;
+ (int)samFaceGetFaceImageParametersWithRawImage:(SamFaceColorImage *)rawImage brightness:(int *)brightness sharpness:(int *)sharpness hotspotsScore:(int *)hotspotsScore hotspotsMask:(unsigned char *)hotspotsMask;
+ (int)samFaceDetectFacesWithImageParametersWithRawImage:(SamFaceColorImage *)rawImage options:(int)options maxCandidates:(int)maxCandidates paramWidth:(unsigned int)paramWidth paramHeight:(unsigned int)paramHeight boundingBoxes:(int *)boundingBoxes confidence:(int *)confidence faceParams:(int *)faceParams brightness:(int *)brightness sharpness:(int *)sharpness hotspotsScore:(int *)hotspotsScore;
+ (int)samFaceResizeWithImage:(SamFaceColorImage *)image outImage:(SamFaceColorImage *)outImage;
+ (int)samFaceCropWithImage:(SamFaceColorImage *)image x:(int)x y:(int)y outImage:(SamFaceColorImage *)outImage resizeRatio:(double)resizeRatio borderColor:(unsigned int)borderColor;
+ (int)samFaceWarpPerspectiveWithImage:(SamFaceColorImage *)image cornerPoints:(int *)cornerPoints outImage:(SamFaceColorImage *)outImage outCornerPoints:(int *)outCornerPoints borderColor:(unsigned int)borderColor;

@end

NS_ASSUME_NONNULL_END
