//
//  SamFace.h
//  SamFace
//
//  Created by Jakub Vallo on 01/04/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for SamFace.
FOUNDATION_EXPORT double SamFaceVersionNumber;

//! Project version string for SamFace.
FOUNDATION_EXPORT const unsigned char SamFaceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SamFace/PublicHeader.h>

#import <SamFace/DOTSamFace.h>
