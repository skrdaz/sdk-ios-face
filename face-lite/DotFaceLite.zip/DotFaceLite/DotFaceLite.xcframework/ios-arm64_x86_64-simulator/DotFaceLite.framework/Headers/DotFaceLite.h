//
//  DotFaceLite.h
//  DotFaceLite
//
//  Created by Jakub Vallo on 04/02/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for DotFaceLite.
FOUNDATION_EXPORT double DotFaceLiteVersionNumber;

//! Project version string for DotFaceLite.
FOUNDATION_EXPORT const unsigned char DotFaceLiteVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DotFaceLite/PublicHeader.h>


