//
//  DotProtocolBuffers.h
//  DotProtocolBuffers
//
//  Created by Jakub Vallo on 23/12/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for DotProtocolBuffers.
FOUNDATION_EXPORT double DotProtocolBuffersVersionNumber;

//! Project version string for DotProtocolBuffers.
FOUNDATION_EXPORT const unsigned char DotProtocolBuffersVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DotProtocolBuffers/PublicHeader.h>

#import <DotProtocolBuffers/DOTGPBMessageFactory.h>
